package com.pactice.boot.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pactice.boot.Entity.Task;

@Repository
public interface TaskManagementRepo extends JpaRepository<Task,Long> {
    
}

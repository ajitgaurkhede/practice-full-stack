package com.pactice.boot.Model;

public class GameModel {
    private String Word;
    private int remainTRy;
    private String msg;

    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }

    public int getRemainTRy() {
        return remainTRy;
    }
    public void setRemainTRy(int remainTRy) {
        this.remainTRy = remainTRy;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    

}

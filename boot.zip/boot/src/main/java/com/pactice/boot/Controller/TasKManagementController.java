package com.pactice.boot.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pactice.boot.Dto.TaskDto;
import com.pactice.boot.Entity.Task;
import com.pactice.boot.Services.TaskManagementService;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class TasKManagementController {

    private TaskManagementService managementService;

    public TasKManagementController(TaskManagementService managementService) {
        this.managementService = managementService;
    }

    @GetMapping("/get-tasks")
    public List<TaskDto> getAllTask() {
        return managementService.findAllTask();
    }

    @PostMapping("/save-task")
    public ResponseEntity<TaskDto> saveTask(@RequestBody TaskDto taskDto) {

        taskDto = managementService.saveTask(taskDto);
        return new ResponseEntity<>(taskDto, HttpStatus.CREATED);

    }

    @DeleteMapping("/delete-task/{id}")
    public ResponseEntity<Object> deleteTask(@PathVariable Long id) {
        managementService.deleteTask(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @PutMapping("/update-task/{id}")
    public ResponseEntity<TaskDto> updateTask(@PathVariable Long id , @RequestBody TaskDto taskDto){
        managementService.updateTask(id,taskDto);
        return new ResponseEntity<>(taskDto, HttpStatus.CREATED);
    }

}

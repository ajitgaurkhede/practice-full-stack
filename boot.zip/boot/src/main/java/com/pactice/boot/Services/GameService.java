package com.pactice.boot.Services;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("prototype")
public class GameService {

    @Autowired
    ConfigurableApplicationContext context;

    private String[] randomWords = { "father", "mother", "sister", "string", "hello", "light", "java" };

    Random random = new Random();

    private String randomlyChoosenWord = null;

    private char[] allCharacterOfTheWord;

    public GameService() {
        randomlyChoosenWord = randomWords[random.nextInt(randomWords.length)];
        System.out.println("random choosen word " + randomlyChoosenWord);
        allCharacterOfTheWord = new char[randomlyChoosenWord.length()];

    }

    @Override
    public String toString() {

        String ret = "";

        for (char c : allCharacterOfTheWord) {
            if (c == '\u0000') {
                ret = ret + "_";
            } else {
                ret = ret + c;
            }

            ret = ret + " ";
        }

        return ret;
    }

    public boolean addGuess(char guessedChar) {
        boolean isGuessCorrect = false;
        for (int i = 0; i < randomlyChoosenWord.length(); i++) {
            if (guessedChar == randomlyChoosenWord.charAt(i)) {

                allCharacterOfTheWord[i] = guessedChar;
                isGuessCorrect = true;
            }

        }
        return isGuessCorrect;

    }

    public GameService reloade() {
        GameService gameService = context.getBean(GameService.class);

        return gameService;

    }

}

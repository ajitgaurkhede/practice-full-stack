package com.pactice.boot.Util;

import org.springframework.stereotype.Component;

@Component
public class GameUtil {
    private int MAX_TRIES = 5;

    public int reduceTry(){

        if(MAX_TRIES != 0){
        MAX_TRIES = MAX_TRIES - 1;
        }
        return MAX_TRIES;
    }

    public int getTriesrRemaining() {
        return MAX_TRIES;
    }

    public void resetTry(){
        MAX_TRIES = 5;
    }

}

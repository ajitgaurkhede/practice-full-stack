package com.pactice.boot.Services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.pactice.boot.Dto.TaskDto;
import com.pactice.boot.Entity.Task;
import com.pactice.boot.Repo.TaskManagementRepo;

import jakarta.transaction.Transactional;

@Service
public class TaskManagementService {

    private TaskManagementRepo managementRepo;
    private ModelMapper mapper;

    public TaskManagementService(TaskManagementRepo managementRepo, ModelMapper mapper) {
        this.managementRepo = managementRepo;
        this.mapper = mapper;
    }

    public List<TaskDto> findAllTask() {
        return managementRepo.findAll().stream().map(task -> mapper.map(task, TaskDto.class)).toList();
    }

    @Transactional
    public TaskDto saveTask(TaskDto taskDto) {
        if (taskDto != null) {
            Task task = mapper.map(taskDto, Task.class);
            managementRepo.save(task);
        }
        return taskDto;
    }

    @Transactional
    public void deleteTask(Long id) {
        managementRepo.deleteById(id);
    }

    @Transactional
    public void updateTask(Long id, TaskDto taskDto) {
        Task task = managementRepo.getReferenceById(id);
        mapper.map(taskDto, task);
        managementRepo.save(task);
    }

}

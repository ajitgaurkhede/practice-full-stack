package com.pactice.boot.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pactice.boot.Model.GameModel;
import com.pactice.boot.Services.GameService;
import com.pactice.boot.Util.GameUtil;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class GameController {

    @Autowired
    GameService gameService;

    @Autowired
    GameUtil gameUtil;

    @GetMapping("/game-home")
    public GameModel showGameHomePage(@RequestParam(name = "wordChar", required = false) String wordChar) {

        System.out.println(wordChar);

        GameModel model = new GameModel();

        if (wordChar != null) {
            boolean isGuessCorrect = gameService.addGuess(wordChar.charAt(0));
            if (!isGuessCorrect) {
                gameUtil.reduceTry();
            }
        }
        model.setWord(gameService.toString());
        model.setRemainTRy(gameUtil.getTriesrRemaining());
        if (gameUtil.getTriesrRemaining() == 0) {
            model.setMsg("Max limi reached thanks");
        } else {
            model.setMsg("");
        }

        return model;
    }

    @GetMapping("/game-home/reload")
    public String reload() {
        gameService = gameService.reloade();
        gameUtil.resetTry();
        return "App realoaded";
    }

}
